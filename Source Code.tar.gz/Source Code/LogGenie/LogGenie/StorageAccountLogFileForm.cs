﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzureMonitorLogViewer
{
    public partial class StorageAccountLogFileForm : Form
    {
        //private ArrayList logFilePath;
        public string logFilePath { get; set; }

        //public StorageAccountLogFileForm(ref ArrayList filePath)
        public StorageAccountLogFileForm()
        {
            //logFilePath = filePath;
            InitializeComponent();
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
        }

        private void btnSubmitLogFilePath_Click(object sender, EventArgs e)
        {
            //logFilePath.Add(this.txtLogFilePath.Text);
            logFilePath = this.txtLogFilePath.Text;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
