﻿using System.Windows.Forms;

namespace AzureMonitorLogViewer
{
    partial class frmLogViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Storage Accounts");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Log Sink", new System.Windows.Forms.TreeNode[] {
            treeNode5});
            this.panelConnection = new System.Windows.Forms.Panel();
            this.treeViewConnection = new System.Windows.Forms.TreeView();
            this.panelLogView = new System.Windows.Forms.Panel();
            this.btnClearLogs = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnExportToCSV = new System.Windows.Forms.Button();
            this.btnAddLogs = new System.Windows.Forms.Button();
            this.dataGridViewLogs = new System.Windows.Forms.DataGridView();
            this.lblRowCount = new System.Windows.Forms.Label();
            this.panelConnection.SuspendLayout();
            this.panelLogView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLogs)).BeginInit();
            this.SuspendLayout();
            // 
            // panelConnection
            // 
            this.panelConnection.Controls.Add(this.treeViewConnection);
            this.panelConnection.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelConnection.Location = new System.Drawing.Point(0, 0);
            this.panelConnection.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelConnection.Name = "panelConnection";
            this.panelConnection.Size = new System.Drawing.Size(472, 795);
            this.panelConnection.TabIndex = 0;
            //
            //Context Menu
            //
            ContextMenuStrip contextMenu = new ContextMenuStrip();
            ToolStripMenuItem connectToStorage = new ToolStripMenuItem();
            connectToStorage.Text = "Add Storage account";
            connectToStorage.Click += (sender, EventArgs) => { treeView_Connect_To_StorageAccount(sender, EventArgs, "Add Storage account", this.treeViewConnection.Nodes["NodeLogSink"].Nodes["ChildNodeSA"]); };
            contextMenu.Items.AddRange(new ToolStripMenuItem[] { connectToStorage });
            // 
            // treeViewConnection
            // 
            this.treeViewConnection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeViewConnection.Location = new System.Drawing.Point(0, 0);
            this.treeViewConnection.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewConnection.Name = "treeViewConnection";
            treeNode5.Name = "ChildNodeSA";
            treeNode5.Text = "Storage Accounts";
            treeNode6.Name = "NodeLogSink";
            treeNode6.Text = "Log Sink";
            this.treeViewConnection.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode6});
            this.treeViewConnection.Size = new System.Drawing.Size(472, 795);
            this.treeViewConnection.TabIndex = 0;
            this.treeViewConnection.Nodes["NodeLogSink"].Nodes["ChildNodeSA"].ContextMenuStrip = contextMenu;
            // 
            // panelLogView
            // 
            this.panelLogView.Controls.Add(this.lblRowCount);
            this.panelLogView.Controls.Add(this.btnClearLogs);
            this.panelLogView.Controls.Add(this.btnExportToExcel);
            this.panelLogView.Controls.Add(this.btnExportToCSV);
            this.panelLogView.Controls.Add(this.btnAddLogs);
            this.panelLogView.Controls.Add(this.dataGridViewLogs);
            this.panelLogView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLogView.Location = new System.Drawing.Point(472, 0);
            this.panelLogView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLogView.Name = "panelLogView";
            this.panelLogView.Size = new System.Drawing.Size(723, 795);
            this.panelLogView.TabIndex = 1;
            // 
            // btnExportToCSV
            // 
            this.btnExportToCSV.Location = new System.Drawing.Point(10, 950);
            this.btnExportToCSV.Name = "btnExportToCSV";
            this.btnExportToCSV.Size = new System.Drawing.Size(150, 40);
            this.btnExportToCSV.TabIndex = 1;
            this.btnExportToCSV.Text = "Export To CSV";
            this.btnExportToCSV.UseVisualStyleBackColor = true;
            this.btnExportToCSV.Click += new System.EventHandler(this.btnExportToCSV_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Location = new System.Drawing.Point(185, 950);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(150, 40);
            this.btnExportToExcel.TabIndex = 1;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnAddLogs
            //
            this.btnAddLogs.Location = new System.Drawing.Point(360, 950);
            this.btnAddLogs.Name = "btnAddLogs";
            this.btnAddLogs.Size = new System.Drawing.Size(150, 40);
            this.btnAddLogs.TabIndex = 1;
            this.btnAddLogs.Text = "Add Logs";
            this.btnAddLogs.UseVisualStyleBackColor = true;
            this.btnAddLogs.Click += new System.EventHandler(this.btnAddLogs_Click);
            // 
            // btnClearLogs
            // 
            this.btnClearLogs.Location = new System.Drawing.Point(535, 950);
            this.btnClearLogs.Name = "btnClearLogs";
            this.btnClearLogs.Size = new System.Drawing.Size(150, 40);
            this.btnClearLogs.TabIndex = 2;
            this.btnClearLogs.Text = "Clear Logs";
            this.btnClearLogs.UseVisualStyleBackColor = true;
            this.btnClearLogs.Click += new System.EventHandler(this.btnClearLogs_Click);
            // 
            // dataGridViewLogs
            // 
            this.dataGridViewLogs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLogs.Location = new System.Drawing.Point(10, 95);
            this.dataGridViewLogs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewLogs.Name = "dataGridViewLogs";
            this.dataGridViewLogs.RowHeadersWidth = 51;
            this.dataGridViewLogs.RowTemplate.Height = 24;
            this.dataGridViewLogs.Size = new System.Drawing.Size(703, 640);
            this.dataGridViewLogs.TabIndex = 0;
            // 
            // lblRowCount
            // 
            this.lblRowCount.AutoSize = true;
            this.lblRowCount.Location = new System.Drawing.Point(6, 54);
            this.lblRowCount.Name = "lblRowCount";
            this.lblRowCount.Size = new System.Drawing.Size(189, 20);
            this.lblRowCount.TabIndex = 3;
            this.lblRowCount.Text = "Number of loaded rows: 0";
            // 
            // frmLogViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1195, 795);
            this.Controls.Add(this.panelLogView);
            this.Controls.Add(this.panelConnection);
            this.Name = "frmLogViewer";
            this.Text = "Log Genie";
            this.panelConnection.ResumeLayout(false);
            this.panelLogView.ResumeLayout(false);
            this.panelLogView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLogs)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panelConnection;
        private System.Windows.Forms.Panel panelLogView;
        private System.Windows.Forms.TreeView treeViewConnection;
        private DataGridView dataGridViewLogs;
        private Button btnClearLogs;
        private Button btnExportToExcel;
        private Button btnExportToCSV;
        private Button btnAddLogs;
        private ContextMenuStrip contextMenu;
        private ToolStripMenuItem connectToStorage;
        private Label lblRowCount;
    }
}