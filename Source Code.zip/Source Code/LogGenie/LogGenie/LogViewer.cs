﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AzureMonitorLogViewer
{
    public partial class frmLogViewer : Form
    {
        private ArrayList storageAccountConnectionString = new ArrayList();
        private string currentStorageAccountConnectionString = string.Empty;

        DataTable mainDataTable = new DataTable();
        public string currentStorageAccountName = string.Empty;

        public frmLogViewer()
        {
            InitializeComponent();
            InitializeDataGridView();
            InitializeDataTable();

            this.WindowState = FormWindowState.Maximized;
        }

        private void InitializeDataGridView()
        {
            dataGridViewLogs.ReadOnly = true;
            dataGridViewLogs.AllowUserToAddRows = false;
            dataGridViewLogs.RowHeadersVisible = false;
            dataGridViewLogs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;

            foreach (DataGridViewColumn column in dataGridViewLogs.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Automatic;
            }
        }

        private void InitializeDataTable()
        {
            mainDataTable = new DataTable();
        }

        private void SetRowCount(int count)
        {
            lblRowCount.Text = "Number of loaded rows: " + count;
        }

        private void RemoveLabel_Click(object sender, EventArgs e, string storageAccountName)
        {
            var currentNode = treeViewConnection.Nodes.Find(storageAccountName, true);

            if (currentNode != null && currentNode.Length == 1)
            {
                treeViewConnection.Nodes.Remove(currentNode[0]);
                treeViewConnection.Nodes["NodeLogSink"].Nodes["ChildNodeSA"].ContextMenuStrip.Enabled = true;


                if (storageAccountConnectionString.Count == 1)
                {
                    storageAccountConnectionString.RemoveAt(0);
                    ClearLogs();
                }
            }
        }

        private async void treeView_Connect_To_StorageAccount(object sender, EventArgs e, string currentNodeText, TreeNode currentNode)
        {
            var numberOfStorageAccounts = storageAccountConnectionString.Count;

            if (storageAccountConnectionString.Count == 0)
            {
                if (currentNodeText == "Add Storage account")
                {
                    try
                    {
                        StorageAccountLoginForm storageLoginForm = new StorageAccountLoginForm(ref storageAccountConnectionString);

                        if (storageLoginForm.ShowDialog(this) == DialogResult.OK)
                        {
                            currentStorageAccountConnectionString = storageLoginForm.SAConnectionString;

                            string connectionString = storageAccountConnectionString[0].ToString();

                            var containerList = await AddStorageAccount(connectionString);

                            var storageAccountName = GetStorageAccountName(currentStorageAccountConnectionString);

                            var treeNodeStorageAccount = new TreeNode(storageAccountName);
                            treeNodeStorageAccount.Name = storageAccountName;

                            //Create context menu for root node to add the remove option
                            ContextMenuStrip contextMenu = new ContextMenuStrip();
                            ToolStripMenuItem removeLabel = new ToolStripMenuItem();
                            removeLabel.Text = "Remove";
                            removeLabel.Click += (i, j) => RemoveLabel_Click(sender, e, storageAccountName);

                            contextMenu.Items.AddRange(new ToolStripMenuItem[] { removeLabel });
                            treeNodeStorageAccount.ContextMenuStrip = contextMenu;

                            currentNode.Nodes.Add(treeNodeStorageAccount);

                            currentNode.ContextMenuStrip.Enabled = false;

                            addLogContainersToDestinationStorageAccountTreeView(currentNode.Nodes[storageAccountName], containerList);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }
            else
            {
                if (currentNode.Name == "ChildNodeSA")
                {
                    try
                    {
                        StorageAccountLoginForm storageLoginForm = new StorageAccountLoginForm(ref storageAccountConnectionString);

                        if (storageLoginForm.ShowDialog(this) == DialogResult.OK)
                        {
                            //this.treeViewConnection.Nodes["NodeLogSink"].Nodes["ChildNodeSA"].Nodes.ContainsKey
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }
        }

        private string GetStorageAccountName(string connString)
        {
            var stringData = connString.Split(';');

            var index = Array.FindIndex(stringData, i => i.Contains("AccountName"));

            return stringData[index].Split('=')[1];
        }

        private async Task<List<BlobContainerItem>> AddStorageAccount(string connectionString)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

            var containers = blobServiceClient.GetBlobContainers();

            var myTask = Task.Run(() => blobServiceClient.GetBlobContainers());

            var result = await myTask;

            return result.ToList();
        }

        private void treeView_addLogFile(object sender, EventArgs e, TreeNode currentTreeNode)
        {
            StorageAccountLogFileForm logFileForm = new StorageAccountLogFileForm();

            if (logFileForm.ShowDialog(this) == DialogResult.OK)
            {
                string filePath = logFileForm.logFilePath;

                var nodeText = "";
                var resourceName = "";
                var fileName = "_y=" + filePath.Split(new string[] { "/y=" }, StringSplitOptions.None)[1];

                if (filePath.Contains("providers/Microsoft.Storage"))
                {
                    resourceName = filePath.Split(new string[] { "/storageAccounts/" }, StringSplitOptions.None)[1].Split('/')[0];
                }
                else
                {
                    var resourcePath = filePath.Split(new string[] { "/y=" }, StringSplitOptions.None)[0].Split(new string[] { "/" }, StringSplitOptions.None);
                    resourceName = resourcePath[resourcePath.Length - 1];
                }

                nodeText = resourceName + fileName;

                TreeNode logFileNode = new TreeNode(filePath);
                logFileNode.Name = filePath;

                logFileNode.Text = nodeText;

                ContextMenuStrip contextMenuLogFile = new ContextMenuStrip();
                ToolStripMenuItem logFileMenuItem = new ToolStripMenuItem();
                logFileMenuItem.Text = "Import logs";
                logFileMenuItem.Click += (i, EventArgs) => { treeView_importSelectedLogFile(i, EventArgs, filePath, currentTreeNode.Name); };

                contextMenuLogFile.Items.AddRange(new ToolStripMenuItem[] { logFileMenuItem });

                logFileNode.ContextMenuStrip = contextMenuLogFile;
                currentTreeNode.Nodes.Add(logFileNode);
            }
        }

        private void btnAddLogs_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialogJson = new OpenFileDialog();
            openFileDialogJson.DefaultExt = "json";
            openFileDialogJson.Filter = "JSON files| *.json";
            openFileDialogJson.Multiselect = true;
            openFileDialogJson.RestoreDirectory = true;
            openFileDialogJson.SupportMultiDottedExtensions = true;

            var result = openFileDialogJson.ShowDialog();
            var filePaths = openFileDialogJson.FileNames;

            if (result == DialogResult.OK)
            {
                try
                {
                    this.btnAddLogs.Enabled = false;

                    ClearLogs();

                    LoadJSONData(filePaths);

                    if (dataGridViewLogs.DataSource == null)
                    {
                        dataGridViewLogs.DataSource = mainDataTable;
                        SetRowCount(mainDataTable.Rows.Count);
                    }
                }
                catch (IOException ioexp)
                {
                    MessageBox.Show(ioexp.Message);
                }
            }
        }

        private void copyAlltoClipboard()
        {
            dataGridViewLogs.SelectAll();
            DataObject dataObj = dataGridViewLogs.GetClipboardContent();
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }

        //private void btnExportToExcel_Click(object sender, EventArgs e)
        //{
        //    if (dataGridViewLogs.Rows.Count > 0)
        //    {
        //        SaveFileDialog saveFileDialogJson = new SaveFileDialog();
        //        saveFileDialogJson.Filter = "Excel (.xlsx)|  *.xlsx";
        //        saveFileDialogJson.FileName = "LogFile.xlsx";
        //        bool fileError = false;

        //        if (saveFileDialogJson.ShowDialog() == DialogResult.OK)
        //        {
        //            if (File.Exists(saveFileDialogJson.FileName))
        //            {
        //                try
        //                {
        //                    File.Delete(saveFileDialogJson.FileName);
        //                }
        //                catch (IOException ex)
        //                {
        //                    fileError = true;
        //                    MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
        //                }
        //            }
        //            if (!fileError)
        //            {
        //                try
        //                {

        //                    copyAlltoClipboard();
        //                    Microsoft.Office.Interop.Excel.Application xlexcel;
        //                    Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
        //                    Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
        //                    object misValue = System.Reflection.Missing.Value;

        //                    xlexcel = new Microsoft.Office.Interop.Excel.Application();
        //                    xlexcel.Visible = true;
        //                    xlWorkBook = xlexcel.Workbooks.Add(misValue);
        //                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        //                    Microsoft.Office.Interop.Excel.Range CR = (Microsoft.Office.Interop.Excel.Range)xlWorkSheet.Cells[1, 1];
        //                    CR.Select();
        //                    xlWorkSheet.PasteSpecial(CR, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);

        //                    //Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
        //                    //Microsoft.Office.Interop.Excel._Workbook workbook = XcelApp.Workbooks.Add(Type.Missing);
        //                    //Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

        //                    //worksheet = workbook.Sheets["Sheet1"];
        //                    //worksheet = workbook.ActiveSheet;
        //                    //worksheet.Name = "Output";
        //                    //worksheet.Application.ActiveWindow.SplitRow = 1;
        //                    //worksheet.Application.ActiveWindow.FreezePanes = true;

        //                    //for (int i = 1; i < dataGridViewLogs.Columns.Count + 1; i++)
        //                    //{
        //                    //    worksheet.Cells[1, i] = dataGridViewLogs.Columns[i - 1].HeaderText;
        //                    //    worksheet.Cells[1, i].Font.NAME = "Calibri";
        //                    //    worksheet.Cells[1, i].Font.Bold = true;
        //                    //    worksheet.Cells[1, i].Interior.Color = Color.Wheat;
        //                    //    worksheet.Cells[1, i].Font.Size = 12;
        //                    //}

        //                    //for (int i = 0; i < dataGridViewLogs.Rows.Count; i++)
        //                    //{
        //                    //    for (int j = 0; j < dataGridViewLogs.Columns.Count; j++)
        //                    //    {
        //                    //        worksheet.Cells[i + 2, j + 1] = dataGridViewLogs.Rows[i].Cells[j].Value.ToString();
        //                    //    }
        //                    //}

        //                    xlWorkSheet.Columns.AutoFit();
        //                    xlWorkSheet.SaveAs(saveFileDialogJson.FileName);
        //                    xlexcel.Quit();

        //                    //ReleaseObject(worksheet);
        //                    //ReleaseObject(workbook);
        //                    //ReleaseObject(XcelApp);

        //                    MessageBox.Show("Data Exported Successfully !!!", "Info");
        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Error :" + ex.Message);
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("No Record To Export !!!", "Info");
        //    }
        //}

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            if (dataGridViewLogs.Rows.Count > 0)
            {
                SaveFileDialog saveFileDialogJson = new SaveFileDialog();
                saveFileDialogJson.Filter = "Excel (.xlsx)|  *.xlsx";
                saveFileDialogJson.FileName = "LogFile.xlsx";
                bool fileError = false;

                if (saveFileDialogJson.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(saveFileDialogJson.FileName))
                    {
                        try
                        {
                            File.Delete(saveFileDialogJson.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                            Microsoft.Office.Interop.Excel._Workbook workbook = XcelApp.Workbooks.Add(Type.Missing);
                            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Output";
                            worksheet.Application.ActiveWindow.SplitRow = 1;
                            worksheet.Application.ActiveWindow.FreezePanes = true;

                            for (int i = 1; i < dataGridViewLogs.Columns.Count + 1; i++)
                            {
                                worksheet.Cells[1, i] = dataGridViewLogs.Columns[i - 1].HeaderText;
                                worksheet.Cells[1, i].Font.NAME = "Calibri";
                                worksheet.Cells[1, i].Font.Bold = true;
                                worksheet.Cells[1, i].Interior.Color = Color.Wheat;
                                worksheet.Cells[1, i].Font.Size = 12;
                            }

                            for (int i = 0; i < dataGridViewLogs.Rows.Count; i++)
                            {
                                for (int j = 0; j < dataGridViewLogs.Columns.Count; j++)
                                {
                                    worksheet.Cells[i + 2, j + 1] = dataGridViewLogs.Rows[i].Cells[j].Value.ToString();
                                }
                            }

                            worksheet.Columns.AutoFit();
                            workbook.SaveAs(saveFileDialogJson.FileName);
                            XcelApp.Quit();

                            //ReleaseObject(worksheet);
                            //ReleaseObject(workbook);
                            //ReleaseObject(XcelApp);

                            MessageBox.Show("Data Exported Successfully !!!", "Info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error :" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No Record To Export !!!", "Info");
            }
        }

        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.Message, "Error");
            }
            finally
            {
                GC.Collect();
            }
        }

        private void btnExportToCSV_Click(object sender, EventArgs e)
        {
            if (dataGridViewLogs.Rows.Count > 0)
            {
                SaveFileDialog saveFileDialogCsv = new SaveFileDialog();
                saveFileDialogCsv.Filter = "CSV (*.csv)|*.csv";
                saveFileDialogCsv.FileName = "LogFile.csv";
                bool fileError = false;

                if (saveFileDialogCsv.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(saveFileDialogCsv.FileName))
                    {
                        try
                        {
                            File.Delete(saveFileDialogCsv.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            int columnCount = dataGridViewLogs.Columns.Count;
                            string columnNames = "";
                            string[] outputCsv = new string[dataGridViewLogs.Rows.Count + 1];
                            for (int i = 0; i < columnCount; i++)
                            {
                                columnNames += dataGridViewLogs.Columns[i].HeaderText.ToString() + ",";
                            }
                            outputCsv[0] += columnNames;

                            for (int i = 1; (i - 1) < dataGridViewLogs.Rows.Count; i++)
                            {
                                for (int j = 0; j < columnCount; j++)
                                {
                                    outputCsv[i] += dataGridViewLogs.Rows[i - 1].Cells[j].Value.ToString() + ",";
                                }
                            }

                            File.WriteAllLines(saveFileDialogCsv.FileName, outputCsv, Encoding.UTF8);
                            MessageBox.Show("Data Exported Successfully !!!", "Info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error :" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No Record To Export !!!", "Info");
            }
        }

        private void btnClearLogs_Click(object sender, EventArgs e)
        {
            this.btnAddLogs.Enabled = true;
            ClearLogs();
        }
        private async void treeView_importAllLogFiles(object sender, EventArgs e, TreeNode currentNode)
        {
            if (currentNode.Nodes.Count == 0)
            {
                MessageBox.Show("There are no log files to import. Please add a log file first.");
                return;
            }

            ClearLogs();

            BlobServiceClient blobServiceClient = new BlobServiceClient(currentStorageAccountConnectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(currentNode.Name);

            foreach (TreeNode node in currentNode.Nodes)
            {
                BlobClient blobClient = containerClient.GetBlobClient(node.Name);

                var myTask = Task.Run(() => blobClient.DownloadTo(@"c:\temp\tempfile.json"));

                var result = await myTask;

                LoadJSONData(new string[] { @"c:\temp\tempfile.json" });
            }

            if (dataGridViewLogs.DataSource == null)
            {
                dataGridViewLogs.DataSource = mainDataTable;
                SetRowCount(mainDataTable.Rows.Count);
            }
        }

        private void treeView_clearAllLogs(object sender, EventArgs e)
        {
            ClearLogs();
        }

        private void ClearLogs()
        {
            mainDataTable.Clear();

            if (mainDataTable.Columns.Count > 0)
            {
                foreach (var column in mainDataTable.Columns.Cast<DataColumn>().ToArray())
                {
                    if (mainDataTable.AsEnumerable().All(dr => dr.IsNull(column)))
                        mainDataTable.Columns.Remove(column);
                }
            }

            dataGridViewLogs.DataSource = null;

            SetRowCount(mainDataTable.Rows.Count);
        }

        private async void treeView_importSelectedLogFile(object sender, EventArgs e, string filePath, string currentContainerName)
        {
            ClearLogs();

            BlobServiceClient blobServiceClient = new BlobServiceClient(currentStorageAccountConnectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(currentContainerName);
            BlobClient blobClient = containerClient.GetBlobClient(filePath);

            var myTask = Task.Run(() => blobClient.DownloadTo(@"c:\temp\tempfile.json"));

            var result = await myTask;

            LoadJSONData(new string[] { @"c:\temp\tempfile.json" });

            if (dataGridViewLogs.DataSource == null)
            {
                dataGridViewLogs.DataSource = mainDataTable;
                SetRowCount(mainDataTable.Rows.Count);
            }
        }

        private void LoadJSONData(string[] files)
        {
            try
            {
                foreach (string file in files)
                {
                    StringBuilder jsonData = new StringBuilder();

                    string json = (new WebClient()).DownloadString(file);

                    string[] rows = File.ReadAllLines(file);

                    Dictionary<string, object> data = JsonConvert.DeserializeObject<Dictionary<string, object>>(rows[0]);

                    if (mainDataTable.Columns.Count == 0)
                    {
                        var arrayOfAllKeys = data.Keys.ToArray();

                        foreach (string key in arrayOfAllKeys)
                        {
                            mainDataTable.Columns.Add(key, typeof(object));
                        }
                    }

                    for (int i = 0; i < rows.Length; i++)
                    {
                        var row = rows[i];

                        var rowdata = JsonConvert.DeserializeObject<Dictionary<string, object>>(row);

                        DataRow dr = mainDataTable.NewRow();
                        dr.ItemArray = rowdata.Values.ToArray();
                        mainDataTable.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addLogContainersToDestinationStorageAccountTreeView(TreeNode nodeStorageAccounts, List<BlobContainerItem> listOfContainers)
        {
            XDocument containerList = XDocument.Load(@"LogContainersList.xml");
            var logContainers = containerList.Root.Elements();

            foreach (BlobContainerItem container in listOfContainers)
            {
                if (logContainers.Any(i => i.Value == container.Name))
                {
                    var element = logContainers.FirstOrDefault(i => i.Value == container.Name);

                    var resourceType = element.Attribute("type").Value;

                    var nodeName = "node" + resourceType;

                    if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes[nodeName]))
                    {
                        TreeNode treeNode = new TreeNode(resourceType + " Logs");
                        treeNode.Name = "node" + resourceType;
                        nodeStorageAccounts.Nodes.Add(treeNode);
                    }

                    TreeNode treeNodeContainer = new TreeNode(container.Name);
                    treeNodeContainer.Name = container.Name;

                    ContextMenuStrip contextMenu = new ContextMenuStrip();
                    ToolStripMenuItem addLogsMenuItem = new ToolStripMenuItem();
                    addLogsMenuItem.Text = "Add log file";
                    addLogsMenuItem.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeContainer); };

                    ToolStripMenuItem importLogsMenuItem = new ToolStripMenuItem();
                    importLogsMenuItem.Text = "Import All Logs";
                    importLogsMenuItem.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeContainer); };

                    ToolStripMenuItem clearLogsMenuItem = new ToolStripMenuItem();
                    clearLogsMenuItem.Text = "Clear All Logs";
                    clearLogsMenuItem.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                    contextMenu.Items.AddRange(new ToolStripMenuItem[] { addLogsMenuItem, importLogsMenuItem, clearLogsMenuItem });

                    treeNodeContainer.ContextMenuStrip = contextMenu;

                    nodeStorageAccounts.Nodes[nodeName].Nodes.Add(treeNodeContainer);
                }
            }
        }

        private void addContainersToStorageTreeView(TreeNode nodeStorageAccounts, List<BlobContainerItem> listOfContainers)
        {
            TreeNode treeNodeStorage = new TreeNode("Storage Logs");
            treeNodeStorage.Name = "nodeStorage";

            TreeNode treeNodeRedis = new TreeNode("Redis Logs");
            treeNodeRedis.Name = "nodeRedis";

            if (listOfContainers.Any(i => i.Name == "insights-logs-storageread"))
            {
                if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes["nodeStorage"]))
                {
                    nodeStorageAccounts.Nodes.Add(treeNodeStorage);
                }

                TreeNode treeNodeStorageRead = new TreeNode("insights-logs-storageread");
                treeNodeStorageRead.Name = "insights-logs-storageread";

                ContextMenuStrip contextMenuStorageReadLogs = new ContextMenuStrip();
                ToolStripMenuItem addStorageReadLogs = new ToolStripMenuItem();
                addStorageReadLogs.Text = "Add log file";
                addStorageReadLogs.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeStorageRead); };

                ToolStripMenuItem importStorageReadLogs = new ToolStripMenuItem();
                importStorageReadLogs.Text = "Import All Logs";
                importStorageReadLogs.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeStorageRead); };

                ToolStripMenuItem clearStorageReadLogs = new ToolStripMenuItem();
                clearStorageReadLogs.Text = "Clear All Logs";
                clearStorageReadLogs.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                contextMenuStorageReadLogs.Items.AddRange(new ToolStripMenuItem[] { addStorageReadLogs, importStorageReadLogs, clearStorageReadLogs });

                treeNodeStorageRead.ContextMenuStrip = contextMenuStorageReadLogs;
                treeNodeStorage.Nodes.Add(treeNodeStorageRead);
            }

            if (listOfContainers.Any(i => i.Name == "insights-logs-storagewrite"))
            {
                if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes["nodeStorage"]))
                {
                    nodeStorageAccounts.Nodes.Add(treeNodeStorage);
                }

                TreeNode treeNodeStorageWrite = new TreeNode("insights-logs-storagewrite");
                treeNodeStorageWrite.Name = "insights-logs-storagewrite";

                ContextMenuStrip contextMenuStorageWriteLogs = new ContextMenuStrip();
                ToolStripMenuItem addStorageWriteLogs = new ToolStripMenuItem();
                addStorageWriteLogs.Text = "Add log file";
                addStorageWriteLogs.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeStorageWrite); };

                ToolStripMenuItem importStorageWriteLogs = new ToolStripMenuItem();
                importStorageWriteLogs.Text = "Import All Logs";
                importStorageWriteLogs.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeStorageWrite); };

                ToolStripMenuItem clearStorageWriteLogs = new ToolStripMenuItem();
                clearStorageWriteLogs.Text = "Clear All Logs";
                clearStorageWriteLogs.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                contextMenuStorageWriteLogs.Items.AddRange(new ToolStripMenuItem[] { addStorageWriteLogs, importStorageWriteLogs });

                treeNodeStorageWrite.ContextMenuStrip = contextMenuStorageWriteLogs;
                treeNodeStorage.Nodes.Add(treeNodeStorageWrite);
            }

            if (listOfContainers.Any(i => i.Name == "insights-logs-storagedelete"))
            {
                if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes["nodeStorage"]))
                {
                    nodeStorageAccounts.Nodes.Add(treeNodeStorage);
                }

                TreeNode treeNodeStorageDelete = new TreeNode("insights-logs-storagedelete");
                treeNodeStorageDelete.Name = "insights-logs-storagedelete";

                ContextMenuStrip contextMenuStorageDeleteLogs = new ContextMenuStrip();
                ToolStripMenuItem addStorageDeleteLogs = new ToolStripMenuItem();
                addStorageDeleteLogs.Text = "Add log file";
                addStorageDeleteLogs.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeStorageDelete); };

                ToolStripMenuItem importStorageDeleteLogs = new ToolStripMenuItem();
                importStorageDeleteLogs.Text = "Import All logs";
                importStorageDeleteLogs.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeStorageDelete); };

                ToolStripMenuItem clearStorageDeleteLogs = new ToolStripMenuItem();
                clearStorageDeleteLogs.Text = "Clear All logs";
                clearStorageDeleteLogs.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                contextMenuStorageDeleteLogs.Items.AddRange(new ToolStripMenuItem[] { addStorageDeleteLogs, importStorageDeleteLogs, clearStorageDeleteLogs });

                treeNodeStorageDelete.ContextMenuStrip = contextMenuStorageDeleteLogs;
                treeNodeStorage.Nodes.Add(treeNodeStorageDelete);
            }

            if (listOfContainers.Any(i => i.Name == "insights-logs-msentraauthenticationauditlog"))
            {
                if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes["nodeRedis"]))
                {
                    nodeStorageAccounts.Nodes.Add(treeNodeRedis);
                }

                TreeNode treeNodeRedisEntra = new TreeNode("insights-logs-msentraauthenticationauditlog");
                treeNodeRedisEntra.Name = "insights-logs-msentraauthenticationauditlog";

                ContextMenuStrip contextMenuRedisEntraLogs = new ContextMenuStrip();
                ToolStripMenuItem addRedisEntraLogs = new ToolStripMenuItem();
                addRedisEntraLogs.Text = "Add log file";
                addRedisEntraLogs.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeRedisEntra); };

                ToolStripMenuItem importRedisEntraLogs = new ToolStripMenuItem();
                importRedisEntraLogs.Text = "Import All logs";
                importRedisEntraLogs.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeRedisEntra); };

                ToolStripMenuItem clearRedisEntraLogs = new ToolStripMenuItem();
                clearRedisEntraLogs.Text = "Clear All logs";
                clearRedisEntraLogs.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                contextMenuRedisEntraLogs.Items.AddRange(new ToolStripMenuItem[] { addRedisEntraLogs, importRedisEntraLogs, clearRedisEntraLogs });

                treeNodeRedisEntra.ContextMenuStrip = contextMenuRedisEntraLogs;
                treeNodeRedis.Nodes.Add(treeNodeRedisEntra);
            }

            if (listOfContainers.Any(i => i.Name == "insights-logs-connectedclientlist"))
            {
                if (!nodeStorageAccounts.Nodes.Contains(nodeStorageAccounts.Nodes["nodeRedis"]))
                {
                    nodeStorageAccounts.Nodes.Add(treeNodeRedis);
                }

                TreeNode treeNodeRedisConnClients = new TreeNode("insights-logs-connectedclientlist");
                treeNodeRedisConnClients.Name = "insights-logs-connectedclientlist";

                ContextMenuStrip contextMenuRedisConnectedClientsLogs = new ContextMenuStrip();
                ToolStripMenuItem addRedisConnectedClientsLogs = new ToolStripMenuItem();
                addRedisConnectedClientsLogs.Text = "Add log file";
                addRedisConnectedClientsLogs.Click += (sender, EventArgs) => { treeView_addLogFile(sender, EventArgs, treeNodeRedisConnClients); };

                ToolStripMenuItem importRedisConnectedClientsLogs = new ToolStripMenuItem();
                importRedisConnectedClientsLogs.Text = "Import All logs";
                importRedisConnectedClientsLogs.Click += (sender, EventArgs) => { treeView_importAllLogFiles(sender, EventArgs, treeNodeRedisConnClients); };

                ToolStripMenuItem clearRedisConnectedClientsLogs = new ToolStripMenuItem();
                clearRedisConnectedClientsLogs.Text = "Clear All logs";
                clearRedisConnectedClientsLogs.Click += (sender, EventArgs) => { treeView_clearAllLogs(sender, EventArgs); };

                contextMenuRedisConnectedClientsLogs.Items.AddRange(new ToolStripMenuItem[] { addRedisConnectedClientsLogs, importRedisConnectedClientsLogs, clearRedisConnectedClientsLogs });

                treeNodeRedisConnClients.ContextMenuStrip = contextMenuRedisConnectedClientsLogs;
                treeNodeRedis.Nodes.Add(treeNodeRedisConnClients);
            }
        }
    }
}