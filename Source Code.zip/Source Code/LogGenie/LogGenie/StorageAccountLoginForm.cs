﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzureMonitorLogViewer
{
    public partial class StorageAccountLoginForm : Form
    {
        private ArrayList storageAccountConnectionString;
        public string SAConnectionString { get; set; }
        public StorageAccountLoginForm(ref ArrayList connectionString)
        {
            storageAccountConnectionString = connectionString;
            InitializeComponent();
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
        }

        private void btnStorageAccountConnect_Click(object sender, EventArgs e)
        {
            storageAccountConnectionString.Add(this.txtStorageAccountConnectionString.Text);

            SAConnectionString = this.txtStorageAccountConnectionString.Text;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
