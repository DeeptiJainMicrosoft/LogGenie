﻿namespace AzureMonitorLogViewer
{
    partial class StorageAccountLoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStorageLogin = new System.Windows.Forms.Label();
            this.txtStorageAccountConnectionString = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStorageLogin
            // 
            this.lblStorageLogin.AutoSize = true;
            this.lblStorageLogin.Location = new System.Drawing.Point(12, 27);
            this.lblStorageLogin.Name = "lblStorageLogin";
            this.lblStorageLogin.Size = new System.Drawing.Size(485, 20);
            this.lblStorageLogin.TabIndex = 0;
            this.lblStorageLogin.Text = "Provide your Storage Account Connection String with Access Key: \n(Please make sure that storage account key access is enabled on the storage account)";
            // 
            // txtStorageAccountConnectionString
            // 
            this.txtStorageAccountConnectionString.Location = new System.Drawing.Point(16, 83);
            this.txtStorageAccountConnectionString.Name = "txtStorageAccountConnectionString";
            this.txtStorageAccountConnectionString.Size = new System.Drawing.Size(872, 26);
            this.txtStorageAccountConnectionString.TabIndex = 1;
            this.txtStorageAccountConnectionString.Text = "DefaultEndpointsProtocol=https;AccountName=mystorageaccount;AccountKey=mykey;Endp" +
    "ointSuffix=core.windows.net";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(749, 136);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(115, 40);
            this.btnConnect.TabIndex = 2;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnStorageAccountConnect_Click);
            // 
            // StorageAccountLoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 199);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtStorageAccountConnectionString);
            this.Controls.Add(this.lblStorageLogin);
            this.Name = "StorageAccountLoginForm";
            this.Text = "Connect to the Storage Account";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStorageLogin;
        private System.Windows.Forms.TextBox txtStorageAccountConnectionString;
        private System.Windows.Forms.Button btnConnect;
    }
}